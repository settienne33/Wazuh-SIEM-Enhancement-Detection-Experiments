---
entity type:
  - datasource
source name: ADD NAME HERE
device: 
status:
  - considering
  - planned
  - deployed
  - tested
  - tuned
OSes: 
description: ADD DESCRIPTION HERE
source category:
  - host
  - network
  - application
---
Brief description of what this [[Datasources|datasource]] is all about.

# References
- #LINK-TO-RELEVANT-NOTES-HERE 

# Configuration file(s)
- #LINK-TO-RELEVANT-NOTES-HERE 

# Decoder/parsing notes
- #ADD-YOUR-OWN-ANSWER-HERE 