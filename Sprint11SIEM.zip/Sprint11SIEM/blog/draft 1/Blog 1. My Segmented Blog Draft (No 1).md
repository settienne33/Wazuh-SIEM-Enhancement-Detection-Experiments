*This* is where you will actually author your blog post — the final deliverable for this project.

> [!error] Don't begin to fill these out until you've completed all TODOs in your [[The Plan]] note.

# Table of contents
Use these dedicated notes to write the first drafts of each section of your blog post. *Check them off as you complete them.*

> [!tip] Detailed instructions about each section are included below.

- [ ] [[1. Introduction]]
- [ ] [[2. Setup]]
- [ ] [[3. Experiment time!]]
- [ ] [[4. Conclusion]]
- [ ] [[5. Final thoughts]]
- [ ] [[6. References]]



> [!warning]- TODO checklist to ensure your post contains all the necessary content for your project to be accepted
> **[[1. Introduction]]:**
> - [ ] Brief "teaser" overview alluding to [[5. Final thoughts]] section content
> - [ ] Introduction to yourself and why you find cybersecurity interesting
> 
> **[[2. Setup]]:**
> - [ ] Describe replicable procedure for implementing one (1) [[modification]] to SIEM deployment.
> - [ ] Describe one (1) [[Mistakes|mistake]] made during this modification process.
> 
> **[[3. Experiment time!]]:**
> - [ ] Describe each of the three (3) experiments you ran:
> 	- [ ] Experiment 1
> 	- [ ] Experiment 2
> 	- [ ] Experiment 3
> - [ ] Describe at least one (1) [[Mistakes|mistake]] you made during one of these experiments.
> 
> **[[4. Conclusion]]:**
> - [ ] Summarize and review of the findings from your experiments
> - [ ] Give advice on how to avoid making the same mistakes you made in [[2. Setup]] and [[3. Experiment time!]].
> 
> **[[5. Final thoughts]]:**
> - [ ] 5.1 Describe the coolest thing you learned during this project.
> - [ ] 5.2 Give one piece of advice to another newbie undertaking a similar project.
> - [ ] 5.3 Recommend your most favorite external resource.
> - [ ] 5.4 Thank somebody
> 	- [ ] Gratitude #1
> 	- [ ] Gratitude #2
> 
> [[6. References]]:
> - [ ] At least five (5) references must be listed.
> - [ ] Each reference you include contains:
> 	- [ ] Title
> 	- [ ] Author
> 	- [ ] Author's affiliation *(if known)*
> 	- [ ] Date published *(if listed)*
> 	- [ ] 1-2 sentence description of why resource was useful during this process

Once you have completed this checklist, it's time to concatenate the information contained in these six pages into a single blog post: [[Blog 2. My Unified Blog Draft (No 2)]].

--- 
# Section-specific instructions
## 1. Introduction (`~100-300 words`)
> [!info] Fill this part of your blog out in the [[1. Introduction]] note.


Provide an engaging overview of what you did.

- You should make allusions to the content in your **[[5. Final thoughts|Final thoughts]]** section as “teasers” to make it clear why somebody should be interested in reading this story.
- Your final paragraph in this section should briefly introduce yourself, explaining why you’ve decided to enter cybersecurity, that this is your first contribution to the community — and that you hope somebody out there will find it fun, interesting, or useful.

> [!example]- 🌿 EXAMPLE 🌿: Alex the nurse (and true crime fan) enters infosec!
> How did I get here? Well...I'm Alex, and I used to be a registered nurse. After I watched my hospital suffer a devastating ransomware attack that brought patient care to a complete standstill, I felt so helpless! But then I realized I could put my love of helping people *and* true-crime mysteries together by becoming a cyber security analyst. I'm excited to bring my attention to detail, curiosity, and passion for taking care of others to a much wider audience than I ever could before. And deploying a SIEM is just one step along that journey. While this is my first blog post, it definitely won't be my last! I hope somebody out there finds some part of my experience useful. :)



---
## 2. Setup (`length varies greatly`)
You must make at least additional **one (1) modification** to this baseline SIEM deployment you’ve stood up.

This modification should be listed in your [[Modifications]] page.

- This section describes the modification(s) you made, telling the story of how you accomplished this.
- Include any **commands you used** or **modifications you made to files**. You need to include enough detail that somebody could follow along, so that a reader can understand _what_ you did and _why_ you did it.

That said, this is _not_ meant to be an instructional guide. This is you telling a story of how you did something. So don’t worry about teaching your reader to do what you did. You’re just taking them along for the ride.

> [!error] Use the [[Chosen Changelogs]] note to keep track of the most valuable changelogs associated with this part of the process.

> [!tip]
> You must also describe at least **one (1) mistake** you’ve made in the process, along with **how you identified that there was a problem** and then **worked out a correct solution**. *(Review your documented [[mistakes]] to choose the most interesting one(s) to showcase in your story.)*


> [!example]- 🌿 A very succinct example *(shortened to illustrate general flow)* 🌿
> I chose to tune the Sysmon configuration on the Ubuntu Linux endpoint (`observer`). Since we already have a good starter config on the Windows box (`ad01`), I wanted to explore whether any similar "starter" configs exist for Linux endpoints...and if not, then just crank the knob to 11, see *everything* that can be recorded with Linux Sysmon, and then selectively tune out some of the noisiest artifacts.
> 
> I tried Plan A first: I did some Googling to figure out if there was a starter Sysmon config similar to the one we're already using on the Windows box.
> `[... telling story of how that went ...]`
> So, seems like we're on our own. That's okay! I had a vague idea of what might need to happen here.
> `[... description of some ideas potentially worth exploring and comparing their various pros and cons ...]`
> ...but since I felt fuzzy about the details, I called a friend: I consulted with a tutor about whether this was a solid direction to go into.
> `[... telling story of how that got refined during that interaction ...]`
> Now, finally, I felt like I had a solid Plan B in place. The Plan B is now:
> `[... summary of Plan B ...]`
> Things are getting real now. So, first I prepared the new Sysmon config I'm gonna try loading into `observer`:
> `[... code block of annotated Linux Sysmon config ...]`
> Config prepped, I jumped into the `observer` box and loaded it in using this command:
> `[... description of how this was done ...]`
> Finally, I checked Wazuh to see if we were catching more logs.
> `[... confirmation that modification is working as intended ...]`
> Huh. Wazuh's not showing what I expected.
> `[... description of how you solved the problem and corrected a mistake]`
> Huzzah! It's now working! 
> `</frankenstein meme>`
> Time for some experiments.

---
## 3. Experiment time! (`length varies greatly`)
You must describe at least **three (3) experiments** you ran after standing up the deployment to see what kinds of events appear in the logs.

- This is the most fun part of the blog post!
- These are the [[experiments]] described in [[Experiment 1]], [[Experiment 2]], [[Experiment 3]].

> [!error] Use the [[Chosen Changelogs]] note to keep track of the most valuable changelogs associated with this part of the process.

> [!tip]
> You must also describe at least **one (1) mistake** you’ve made in the process, along with **how you identified that there was a problem** and then **worked out a correct solution**. *(Review your documented [[mistakes]] to choose the most interesting one(s) to showcase in your story.)*

> [!example]- 🌿 A very succinct example *(shortened to illustrate general flow)* 🌿
> Let's run some experiments — hopefully, I'll be able to figure out where the most noise is coming in from this new config, and adjust it accordingly.
> 
> **Experiment #1**
> The first experiment I tried was...
> `[... description of experiment, why you are doing this particular experiment, what you're hoping to see in or do with the results, curiosity sparks ...]`
> I wanted to see how this would end up panning out.
> `[... tell the story of running the first experiment ...]`
> Now was the moment of truth. What would I see?
> `[... description of the findings and/or outcome of the experiment]`
> Well! That was exactly what I expected.
> `[... analysis of findings ...]`
> Onto the second experiment.
> 
> **Experiment #2**
> `[... same general structure as the first experiment's post ...]`
> 
> **Experiment #3**
> `[... same general structure as the first experiment's post ...]`

---
## 4. Conclusion (`~100-300 words`)
The conclusion to your blog post should include:

- A brief overview of the findings from each of your experiments.
- A warning about how to avoid making the same mistakes you made in **[[2. Setup|Setup]]** and **[[3. Experiment time!|Experiment time]].**

> [!example]- 🌿 EXAMPLE 🌿: Always verify your file changes!
> I sure learned my lesson — it's worth double-checking that your configuration file saved correctly *before* you spend hours beating your head against the wall wondering why the agent isn't working properly!

> [!example]- 🌿 EXAMPLE 🌿: Check your search timerange!
> I now know that one of the first things I should double-check when a SIEM search isn't showing me the logs I expected to see is *making sure the timerange I'm searching within is what I intended.* While I only described **one tim**e I made this mistake in my blog post, I actually did this...a bunch of times. At this point I've developed a paranoia about timeranges...

---
## 5. Final thoughts (`~250-600 words`)
This is the juiciest part of your post. You'll describe the coolest thing you learned, your best piece of advice, and your favorite resource from undertaking this journey. Finally, you'll give a few shout-outs to researchers whose work helped you in some way.

### 5.1 The coolest thing you learned
Tell us about **the coolest thing you learned** during this project.

> [!example]- 🌿 EXAMPLE 🌿: "SIEMs are my friend."
> When all is said and done, the thing I'm happiest about learning is how on earth a SIEM parses data captured in raw logs...and transforms it into something **unified** that we can then use to hunt through. I had no idea how this actually worked behind the scenes — or how complicated it can be to tune data sources! — until this experience. Now I can appreciate better how much art goes into detection engineering — and making sure we have visibility into high-signal events.


### 5.2 One piece of advice
At least **one (1) piece of advice** you’d give to anybody embarking on the same sort of project: what do you wish you’d known before starting your own SIEM deployment journey? Document it here.

> [!example]- 🌿 EXAMPLE 🌿: Logging formats
> One thing I wish I'd gone into this understanding is how much variability there is in *how* logs get recorded. Yikes! Understanding a little bit about common formats like [JSON](https://stackoverflow.blog/2022/06/02/a-beginners-guide-to-json-the-data-format-for-the-internet/) and [XML](https://developer.mozilla.org/en-US/docs/Web/XML/Guides/XML_introduction) definitely helps cut down on the spookiness of making sense of a raw log. And [pretty-printers are your friend](https://jsonformatter.org/json-pretty-print).

> [!example]- 🌿 EXAMPLE 🌿: Timezone advice 
> I completely underestimated how much complexity timezones add to timestamps. I wish I'd known how many headaches are prevented by trying to always record logs in UTC format using [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601). I now have very strong feelings about [Daylight Savings Time](https://www.hanselman.com/blog/back-to-basics-daylight-savings-time-bugs-strike-again-with-setlastmodified). And was delighted (and relieved) to discover that [the moon has its own timezone](https://www.npr.org/2024/04/09/1243405460/space-news-moon-nasa-time-zone-white-house).


### 5.3 Your favorite resource
Highlight at least **one (1) great external resource** you discovered while undertaking this journey. Explain why you found it interesting, how you discovered it _(A tutor? A link from another resource? A Twitter thread?)_, and how you used it to help you understand or accomplish something. *(Use the [[References]] note to keep track of useful resources.)*

> [!example]- 🌿 EXAMPLE 🌿: CERT.JP's Tool Analysis Results Sheet
> My favorite resource through all of this was CERT.JP's **[Tool Analysis Result Sheet](https://jpcertcc.github.io/ToolAnalysisResultSheet/)**. The `Evidence that can be confirmed when execution is successful` section for each lateral movement IOC included in this website is like having access to the answer key! Hat tip to tutor Rick for putting this *fantastic* resource on my radar!

> [!example]- 🌿 EXAMPLE 🌿: LOLBAS and GTFOBins 
> Although this resource wasn't exactly the most critical resource I used throughout this process, I am so happy I discovered the **[LOLBAS](https://lolbas-project.github.io)** and **[GTFOBins](https://gtfobins.github.io)** databases! I noticed that a lot of the entries in these databases actually correspond to stuff that's being done during particular Atomic Red Team atomic tests, so it really helped me understand better why attackers are using these specific TTPs. This kinda stuff is what I really love about cybersecurity — it's not a bug, it's a *feature*! So much creativity and out-of-the-box thinking. (I honestly don't remember where I ran across this resource first...but it *probably* had something to do with[ Casey Smith/@subTee](https://redcanary.com/authors/casey-smith/)...)


### 5.4 Thank somebody!
Explicitly thank at least **two (2) external security researchers** whose work helped you in some way during this process. You could even have a paragraph showing gratitude to _each_ of the researchers whose work you used in some way during your project. But at the very least, at minimum, recognize by name at least two (2). *(Use the [[Gratitudes]] note to keep track of opportunities to thank others as you think of them.)*

> [!tip] Gratitude is the gift that keeps on giving
> Acknowledging who helped you is a standard way of showing respect in the cybersecurity community — and it’s a _great_ way to make new friends. Sometimes you’ll even find a new mentor by tipping your hat to the researchers whose work helped you! The more sincere and thoughtful your note of gratitude, the more likely you’ll make new friends in the industry through your post.

> [!example]- 🌿 EXAMPLE 🌿: Atomic Red Team
> I want to thank the awesome researchers behind **[Atomic Red Team](https://www.atomicredteam.io/)** (like [Matt Graeber](https://redcanary.com/authors/matt-graeber/) and [Casey Smith](https://redcanary.com/authors/casey-smith/) and the other folks at [Red Canary](https://redcanary.com/)) for an **epic** learning experience. While I know that the tool isn't specifically for helping newbies like me get to know the ropes, the ability to emulate so many legitimate TTPs *so easily* in my testing environment has been *utterly amazing!* I'm grateful to be entering cyber security during an era where defenders have access to wonderful open-source tooling like this — I didn't have to learn how to become a pentester just to start playing with legitimate-looking attacks in my environment! 🙌 

> [!example]- 🌿 EXAMPLE 🌿: SIEM trailblazers
> I am profoundly grateful that SIEMs exist. I can't imagine how time-consuming it used to be to correlate TTPs across all these scattered log sources across all these endpoints! It is so dang cool to be able to see all the info I want to see in one centralized place. I want a SIEM for *everything* now! Thank you to all the trailblazers who brought SIEMs into existence in the 2000s.

> [!example]- 🌿 EXAMPLE 🌿: Kim Zetter 
> Shout out to Kim Zetter for sparking my curiosity about cyber security with her 2023 piece "[The Untold Story of the Boldest Supply-Chain Hack Ever](https://www.wired.com/story/the-untold-story-of-solarwinds-the-boldest-supply-chain-hack-ever/)". I never would have found myself on this path if it weren't for that fascinating article!

---
## 6. Annotated resources (`~5–25 entries`)

You must include an **annotated list of references** you found useful while completing this project.

You should review your [[References]] summary to see a full list of all the resources you've added to this vault. 
- Pick and choose the top 5–25 entries listed [[References|here]].
- The more references you include, the better. *(Your blog post will be more likely to appear in other people's search results if you include lots of links to reputable cyber security-related content in your post.)*

> [!tip] 
> Think of the audience for these resources as fellow students learning the same thing as you — you’re _not_ justifying your choices to a teacher; you’re trying to light the way for anybody else trying to retrace your footsteps.


For each resource you include, you must cite:
- The author's **name** (and affiliated **company**, if any).
- **Date** published.
- **Title** of resource. 
- Include a 1–2 sentence **description** of how that resource was relevant to your project.

> [!example]- 🌿 EXAMPLE 🌿: Blasting Past Webp by Ian Beer (Google Project Zero)
> **[Blasting Past Webp: An analysis of the NSO BLASTPASS iMessage exploit](https://googleprojectzero.blogspot.com/2025/03/blasting-past-webp.html)** by Ian Beer (Google Project Zero) `[2025-03-25]`:  
> Yet another amazing walkthrough from Ian Beer. Comprehensive breakdown of the BLASTPASS exploit chain, providing valuable insights into the methods used by APTs to bypass security measures.

