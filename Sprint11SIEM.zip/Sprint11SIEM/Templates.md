All the major [[Entities]] in this Obsidian notebook are associated with a particular template used to add more of a particular entity to this notebook.

## Create a note with a template
The process for creating a new note with a particular template is pretty simple.
1. `alt`/`option ⌥` + `N` to create a new note in the currently-active folder.
2. `alt`/`option ⌥` + `T` to list available templates.
3. Choose the desired template.

> [!tip] Trying to keep your vault's organization tidy?
> Obsidian will create new notes in whatever folder the currently-visible note belongs to. This means the best practice for adding a new entity to your vault is:
> - First visit the home page for the desired new entity (*e.g.,* [[Changelog]], [[Datasources]], [[Devices]], [[Experiments]], [[Files]], [[Modifications]], [[References]], [[Gratitudes]], [[Mistakes]]).
> - *Then* make the new note using  `⌥` + `N`.
> - Finally, insert the appropriate template for the new desired entity using `⌥` + `T.

---
## Fill out a new note
You must always fill out as much of the **front matter** ("`Properties`") as possible for each note in your notebook.
- This'll make it easier for you to see and organize what information is contained here.
- The tables included in each of the entity home pages are populated by what you define in your notes' front matter, so filling these out is important.

The front matter is this stuff at the beginning of the note:
![[Obsidian - front matter properties annot.png]]
This is the easily-editable view. Edit your front matter while using this view.

However, if you've been editing your Markdown, you might find yourself in **Source mode**. That's what is happening when the front matter displays like this:
![[Obsidian - front matter properties - Source mode annot.png]]

> [!tip]- How to get out of Source mode
> You will need to click the three horizontal dots in the upper right-hand corner to disable this mode.
> - Click the three dots.
> - A menu will pop up.
> - De-select the **Source mode** option in the menu.
> - It should look like this afterward:
> - 
> ![[Obsidian - front matter properties - Disable source mode annot.png]]
> And the front matter will be displaying again properly.