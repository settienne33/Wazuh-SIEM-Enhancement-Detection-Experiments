---
entity type:
  - experiment
device: 
description: 
---

# Plan
> [!tip] Keep track of TODO items associated with this experiment here. *Reference your approved [[The Plan]] for this.*

- [ ] ADD
- [ ] TODOs
- [ ] HERE!


# Execution
> [!tip] Record any notes about the execution of this plan. This includes created [[Changelog]] entries, [[Mistakes]], or [[References]] you used while conducting this experiment.

- #ADD-YOUR-OWN-ANSWER-HERE 
- #ADD-YOUR-OWN-ANSWER-HERE 
- #ADD-YOUR-OWN-ANSWER-HERE 

# Findings
> [!tip] Describe the results of your experiment here.

#ADD-YOUR-OWN-ANSWER-HERE 

# References
> [!tip] Add any references you used during this experiment here.

#ADD-YOUR-OWN-ANSWER-HERE 

> [!success] Use the **Linked mentions** section below to discover all other entries that are somehow related to this experiment.