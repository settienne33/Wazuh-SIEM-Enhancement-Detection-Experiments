---
entity type:
  - summary page
description: Home for all gratitudes experienced during this project.
aliases:
  - gratitude
---

Your blog creation process involves progressing through three different drafts of this post:
1. [[Blog 1. My Segmented Blog Draft (No 1)]] = `Draft 1`
2. [[Blog 2. My Unified Blog Draft (No 2)]] = `Draft 2`
3. [[Blog 3. My Unified Blog Draft (No 3)]] = `Draft 3`

> [!success] Once you've completed the [[Blog 3. My Unified Blog Draft (No 3)|third (and final) draft]], you are ready to submit your project for review.

# Draft 1
This your personal, private draft of the blog post: [[Blog 1. My Segmented Blog Draft (No 1)]]. 
- You'll use these pages to piece together your first version of this blog post for your project.
- Different sections are broken out into distinct Obsidian notes to make it easier to track your progress.
- Add the #ADDHERE tag to any sections that you still need to complete. This'll make it easy to track which sections are still missing as you're going through everything.

> [!tip] Instructions on how to craft each section of the six sections of the blog are included in [[Blog 1. My Segmented Blog Draft (No 1)]].



# Draft 2
After [[Blog 1. My Segmented Blog Draft (No 1)|Draft 1]] is completed, use this template to concatenate (join together) all the completed parts of it into a single, unified blog post: [[Blog 2. My Unified Blog Draft (No 2)]]
- After you're done concatenating the six sections into this unified draft ([[Blog 2. My Unified Blog Draft (No 2)|Draft 2]]), you'll copy this content into the blank [[Blog 3. My Unified Blog Draft (No 3)|Draft 3]].


# Draft 3
This is the polished blog post that will be evaluated when you submit your Obsidian notebook for review: [[Blog 3. My Unified Blog Draft (No 3)]].
- You'll use this version of your blog post to use an automated service for checking your work for grammatical errors.
- You'll then proofread this by reading it out loud.
- Finally, you can *(optionally)* ask somebody who knows you well to review your polished blog post — does it still *sound* like you? Make adjustments as needed to make it sound like it's coming from you and your distinct voice/perspective.

> [!danger] The blog post draft that will be formally reviewed when you submit your project is the version contained in [[Blog 3. My Unified Blog Draft (No 3)]].
> The project reviewer may review other parts of your Obsidian notebook if they have questions about why you made certain choices, but generally will only be looking at [[Blog 3. My Unified Blog Draft (No 3)|this single file]] within your Obsidian notebook when you submit your project (*cf. "Submit your blog post" in TripleTen's courseware for more context)*.