---
entity type:
  - reference
title: ART (Invoke-Atomic docs)
URL: https://www.atomicredteam.io/invoke-atomicredteam
published date: 
author: 
author affiliation: 
description: Official website for the PowerShell exec framework I'm using.
blog blurb: 
reference type:
  - website
date added: 
---

# Overview
> [!tip] Describe this resource in brief.
> What do you want to remember about why you saved this resource? Record it here.

Official website for the PowerShell exec framework I'm using. Contains links to instructional YouTube videos for using the framework.


# How did you find this?
> [!tip] Record briefly where you ran into this resource. 
> Was it a Google search, a link on another post, social media...? Keep track of where you found this so you can tell the story accurately.

A link in the TripleTen's courseware.


# Related pages
> [!tip] Link any related notes in this Obsidian notebook to this reference.
> You can also link directly to this note within any other note in the vault. This'll help create backlinks to make it easier to track down where you used this reference during your process.

- #LINK-TO-RELEVANT-NOTES-HERE 


# Quotes
> [!tip] Record any information you might want to quote later from this external resource.

## Quote 1
```
It is recommended to set up a test machine for atomic test execution that is similar to the build in your environment. Be sure you have your collection/EDR solution in place, and that the endpoint is checking in and active.
```
## Quote 2
```
Executing atomic tests may leave your system in an undesirable state. You are responsible for understanding what a test does before executing.
```

# Questions
> [!tip] Sometimes external resources make you ask questions about the material — like "What does this term mean?" or "Why wouldn't people just...?". 
> Use this section to keep track of any questions this resource inspired you to ask. These can be great to track, *especially* if you don't have the time right now to answer those questions!

- Why does executing atomic tests potentially leave my system in an "undesirable state"?
- What do they mean by "undesirable state"?
- Do they expect us to be working with revertible VMs when conducting these tests?


# Notes
> [!tip] Any miscellaneous notes you want to keep about this resource can go into this section.

No notes.