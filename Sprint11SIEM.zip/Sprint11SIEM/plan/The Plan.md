> [!error] Do NOT fill this out until your [[Plan Proposal]] document has been approved!

Convert your approved [[Plan Proposal]] into a Markdown to do list. 
- After your [[Plan Proposal]] has been approved, you should convert it into a TODO List in this document.
- Use the [[TODO List]] as inspiration for your structure!

## Modification #1
> [!tip] You will use the [[Modification No 1]] note to keep track of this modification.

- [ ] ADD
- [ ] TODO
- [ ] ITEMS
- [ ] HERE

## Experiment #1
> [!tip] You will use the [[Experiment 1]] note to keep track of this first experiment.

- [ ] ADD
- [ ] TODO
- [ ] ITEMS
- [ ] HERE

## Experiment #2
> [!tip] You will use the [[Experiment 2]] note to keep track of this second experiment.

- [ ] ADD
- [ ] TODO
- [ ] ITEMS
- [ ] HERE

## Experiment #3
> [!tip] You will use the [[Experiment 3]] note to keep track of this third experiment.

- [ ] ADD
- [ ] TODO
- [ ] ITEMS
- [ ] HERE

> [!success] Completed everything you needed to do in this document?
> GREAT! It's time to start filling out your first draft of the blog post: **[[Blog 1. My Segmented Blog Draft (No 1)]]**