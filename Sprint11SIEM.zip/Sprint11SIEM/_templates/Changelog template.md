---
entity type:
  - changelog
date: {{date}}T{{time}}
change type: 
device: 
description: ADD DESCRIPTION HERE
include in blog?: 
---
Enter a one-sentence summary of what change you made to the environment.

> [!tip] Describe the changes made, including details about any of the following: file modifications, commands run, mistake made, mistake fixed, verified modification, or...anything else you want to keep track of!

#ADD-YOUR-OWN-ANSWER-HERE 


# Related entries
> [!tip] Note whether this change is related to any particular [[Modifications]], [[Experiments]], [[Datasources]], [[Files]], or [[Mistakes]].
- #LINK-TO-RELEVANT-NOTES-HERE 
- ADD
- RELATED
- ENTRIES
- HERE



# Screenshots
> [!tip] Paste any screenshots you took documenting this change here. *They will be saved to the `_attachments` folder.*
> For each screenshot you attach, try to include some context about what exactly that screenshot is depicting (think of it like writing a note to your future self asking the question "Why did I record this?").

## Screenshot 1
