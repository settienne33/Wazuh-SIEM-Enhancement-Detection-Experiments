---
entity type:
  - summary page
description: Home for all references used during this project.
aliases:
  - reference
---

> [!faq]- Want to add a new reference entry?
> - `alt`/`option ⌥` + `N` to create a new note in this references folder.
> - `alt`/`option ⌥` + `T` to list available templates.
> - Choose the **[[References template]]**.


This is where you can track all the external references you use during your project.

```dataviewjs
dv.table(
  ["Reference", "Title", "Description", "Type"],
  dv.pages()
    .where(p => p["entity type"] && p["entity type"].includes("reference"))
    .sort(p => p.Date, 'desc')
    .map(p => [
      p.file.link,
      (Array.isArray(p.title) ? p.title.join(", ") : p.title ?? ""),
      p.description ?? "",
      (Array.isArray(p["reference type"]) ? p["reference type"].join(", ") : p["reference type"] ?? "")
    ])
);
```
