---
entity type:
  - summary page
description: Home for all mistakes worked through during this project.
aliases:
  - mistakes
---

> [!faq]- Made a mistake or experienced an AHA! moment?
> - `alt`/`option ⌥` + `N` to create a new note in this mistakes folder.
> - `alt`/`option ⌥` + `T` to list available templates.
> - Choose the **[[Mistake template]]**.

Any mistakes you've added to your vault will appear below:
```dataviewjs
dv.table(
  ["Mistake", "Name", "Description"],
  dv.pages()
    .where(p =>
      Array.isArray(p["entity type"]) &&
      p["entity type"].includes("mistake") &&
      p.file.name !== "Mistake template"
    )
    .map(p => [
      p.file.link,
      p.name ?? "",
      p.description ?? ""
    ])
);
```

## Tracking mistakes & eureka! moments
You want to track all mistakes and AHA! moments you experience as you complete this project:
- **Mistakes and missteps.** Don’t hide them — _highlight_ them. Some of the most powerful parts of your blog will come from moments when you realized you misunderstood something, adjusted course, and kept going. That’s where real growth lives...and where you can let your problem-solving skills really shine.
- **Shifts in your understanding.** Pay attention to those “Ohhh…_now_ I get it” moments. Surprise is often a sign that you’ve just corrected a misconception — and those turning points make for rich storytelling. These details are some of the juiciest reads, especially for experts reading the post!

## Mistakes are a feature, not a bug!
As you proceed along your plan, you will find yourself making mistakes. These make for absolutely fantastic content to add to your blog post, so be sure to fill out a mistake template each time for any significant or frustrating mistakes — or times where you experienced an “aha!” moment

These mistakes are a critical part of the story you will be telling with your blog post. In cyber security, the ability to grow from your mistakes is so valuable that it’s actually considered an extremely desirable trait for cybersec practitioners to publicly share their mistakes — alongside how they recognized it, and how they solved the problem after realizing something’s not working. There’s no room for ego here — only growing.

That’s _why_ you want to track these. Let’s be super clear here: absolutely NOBODY will think you are stupid or unqualified if you describe your mistakes in your post — in fact, cyber security pros flaunt their learning processes like **a badge of honor**. Mistakes are some of the most tangible ways to make that learning process come alive for others.

And this isn’t just about showing off to the community; this is _also_ something potential employers will be curious about. You are showcasing your problem-solving skills when you include your mistakes in the story your blog tells. Each mistake is an opportunity to show off how you approach problems — _and successfully get to the bottom of them._ Potential employers reviewing your blogs will look for evidence that you can figure things out on your own. This blog is your opportunity to show them that you’re capable of doing _just that_.

> [!tip]
> In your published blog post, you probably won’t highlight _every single mistake_ you’ve recorded in your Obsidian vault. Still: try to fill out a **Mistakes entry** for of all the ones you _do_ make.
> 
> Why? So that you’ll have **several mistakes to choose from** when it comes to deciding which content to put into your blog! At the end of this process, you’ll be able to look at all of them as a group — and you can **pick the one(s) that most vividly highlight your problem-solving skills and/or creativity**.