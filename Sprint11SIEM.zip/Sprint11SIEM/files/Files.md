---
entity type:
  - summary page
description: Home for all files used in this deployment.
aliases:
  - file
---
> [!faq]- Want to add a new file entry?
> - `alt`/`option ⌥` + `N` to create a new note in this file folder.
> - `alt`/`option ⌥` + `T` to list available templates.
> - Choose the **[[Files template]]**.

Any files associated with your deployment can be tracked here.  *These tend to be associated with [[Changelog]] and [[Modifications]] entries.*

```dataviewjs
dv.table(
  ["File note", "Filename", "Device", "Description"],
  dv.pages()
    .where(p => 
      p["entity type"] && 
      p["entity type"].includes("file") &&
      p.file.name !== "Files template"
    )
    .map(p => [
      p.file.link,
      (Array.isArray(p.name) ? p.name.join(", ") : p.name ?? ""),
      (Array.isArray(p.device) ? p.device.join(", ") : p.device ?? ""),
      p.description ?? ""
    ])
);
```