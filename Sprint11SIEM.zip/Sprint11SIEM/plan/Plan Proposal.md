> [!error] The template for drafting the Plan Proposal you will submit is located at [[Sprint 11] Plan Proposal {TEMPLATE}](https://docs.google.com/document/d/1YucMFQkxTsEOUkATCz_tSyeSLmLPpq3MiQVyEALLKRg/copy).
> After your **Plan Proposal** document has been approved by an expert reviewer, *then* you should paste the relevant content into this document. After that, you can use this to fill out the [[Modifications]] and [[Experiments]] notes. Then add the TODOs from those notes into the [[The Plan]] document.

---
# Modifications to environment
### Modification #1
==Describe your proposed modification here== 

#### References to use while implementing
- [ ] ADD
- [ ] REFERENCE

---
---
---

# Experiments to run
### Experiment #1
==Describe your first proposed experiment here==

#### References to use while conducting
- [ ] ADD
- [ ] REFERENCE

---
### Experiment #2
==Describe your second proposed experiment here==

#### References to use while conducting
- [ ] ADD
- [ ] REFERENCE

---
### Experiment #3
==Describe your third proposed experiment here==

#### References to use while conducting
- [ ] ADD
- [ ] REFERENCE