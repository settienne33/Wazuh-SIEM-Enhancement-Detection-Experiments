---
entity type:
  - summary page
description: Home for all the experiments.
aliases:
  - experiment
---
> [!faq]- Want to add a new Experiments entry?
> - `alt`/`option ⌥` + `N` to create a new note in this experiments folder.
> - `alt`/`option ⌥` + `T` to list available templates.
> - Choose the **[[Experiment template]]**.

Track your experiments here.

## Required experiments
- [[Experiment 1]]
- [[Experiment 2]]
- [[Experiment 3]]


## Additional experiments
If you've decided to do more than three (3) experiments, you can link to them above or use the table below to keep track of them all. 

> [!error] You only need to complete three (3) experiments before you're ready to write the [[Blog]].

```dataviewjs
dv.table(
  ["Experiment", "Description"],
  dv.pages()
    .where(p =>
      Array.isArray(p["entity type"]) &&
      p["entity type"].includes("experiment") &&
      p.file.name !== "Experiment template"
    )
    .map(p => [
      p.file.link,
      p.description ?? ""
    ])
);
```