---
entity type:
  - device
device:
  - USERENDPOINT
monitored?: 
OSes:
  - Windows
IP: 10.171.0.2
description: Honeypot.
---

KFSensor honeypot.

# Relevant changelog entries
> [!tip] Any changelog entries involving this device are listed here. *You can also manually add links to any particularly important entries associated with this device.*

```dataviewjs
function formatDate(dateStr) {
  const d = new Date(dateStr);
  if (isNaN(d)) return "";
  const pad = (n) => n.toString().padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} @ ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function wrapText(content, maxWidthPx) {
  const text = Array.isArray(content) ? content.join(", ") : (content ?? "");
  return `<div style="max-width: ${maxWidthPx}px; word-wrap: break-word; white-space: normal;">${text}</div>`;
}

function wrapLink(linkObj, maxWidthPx) {
  return linkObj
    ? `<span style="max-width: ${maxWidthPx}px; display: inline-block; word-wrap: break-word; white-space: normal;">${linkObj}</span>`
    : "";
}

dv.table(
  ["Note", "Date", "Type", "Description"],
  dv.pages()
    .where(p =>
      p["entity type"] &&
      p["entity type"].includes("changelog") &&
      (
        p.device === "USERENDPOINT" ||
        (Array.isArray(p.device) && p.device.includes("USERENDPOINT"))
      )
    )
    .sort(p => p.date, "asc")
    .map(p => [
      wrapLink(p.file.link, 150),
      p.date ? wrapText(formatDate(p.date), 100) : "",
      wrapText(p["change type"], 200),
      p.description ?? ""
    ])
);
```


# Files
> [!tip] Any relevant files are listed here. *You can also manually add links to any particularly important entries associated with this device.*

```dataviewjs
dv.table(
  ["Note", "Name", "Description"],
  dv.pages()
    .where(p => 
      p["entity type"] && 
      p["entity type"].includes("file") &&
      p.device &&
      (
        (Array.isArray(p.device) && p.device.includes("USERENDPOINT")) ||
        p.device === "USERENDPOINT"
      )
    )
    .map(p => [
      p.file.link,
      (Array.isArray(p.name) ? p.name.join(", ") : p.name ?? ""),
      p.description ?? ""
    ])
);
```


# Data sources
> [!tip] Any relevant data sources are listed here. *You can also manually add links to any particularly important entries associated with this device.*

```dataviewjs
dv.table(
  ["Note", "Name", "Category", "OSes", "Status", "Description"],
  dv.pages()
    .where(p => 
      p["entity type"] && 
      p["entity type"].includes("datasource") &&
      p.device &&
      (
        (Array.isArray(p.device) && p.device.includes("USERENDPOINT")) ||
        p.device === "USERENDPOINT"
      )
    )
    .map(p => [
      p.file.link,
      (Array.isArray(p["source name"]) ? p["source name"].join(", ") : p["source name"] ?? ""),
      (Array.isArray(p["source category"]) ? p["source category"].join(", ") : p["source category"] ?? ""),
      (Array.isArray(p.OSes) ? p.OSes.join(", ") : p.OSes ?? ""),
      (Array.isArray(p.status) ? p.status.join(", ") : p.status ?? ""),
      p.description ?? ""
    ])
);
```




















































