---
entity type:
  - summary page
description: Home for all data sources used in this deployment.
aliases:
  - datasource
---

> [!faq]- Want to add a new datasource entry?
> - `alt`/`option ⌥` + `N` to create a new note in this datasource folder.
> - `alt`/`option ⌥` + `T` to list available templates.
> - Choose the **[[Datasource template]]**.

```dataviewjs
dv.table(
  ["Datasource", "Name", "Category", "OSes", "Status", "Description"],
  dv.pages()
    .where(p => p["entity type"] && p["entity type"].includes("datasource"))
    .map(p => [
      p.file.link,
      (Array.isArray(p["source name"]) ? p["source name"].join(", ") : p["source name"] ?? ""),
      (Array.isArray(p["source category"]) ? p["source category"].join(", ") : p["source category"] ?? ""),
      (Array.isArray(p.OSes) ? p.OSes.join(", ") : p.OSes ?? ""),
      (Array.isArray(p.status) ? p.status.join(", ") : p.status ?? ""),
      p.description ?? ""
    ])
);
```
