---
entity type:
  - summary page
description: Home for all devices used in this environment.
aliases:
  - device
---


This page displays all the possible devices in your deployment.
- You can access these devices from Cloudshare's **VM List** tab.
- Credentials for accessing any of these devices are also included in the **VM List** tab.

```dataviewjs
function wrapText(content, maxWidthPx) {
  const text = Array.isArray(content) ? content.join(", ") : (content ?? "");
  return `<div style="max-width: ${maxWidthPx}px; word-wrap: break-word; white-space: normal;">${text}</div>`;
}

function wrapLink(linkObj, maxWidthPx) {
  return linkObj
    ? `<span style="max-width: ${maxWidthPx}px; display: inline-block; word-wrap: break-word; white-space: normal;">${linkObj}</span>`
    : "";
}

function renderCheckbox(value) {
  return value === true
    ? `<input type="checkbox" checked disabled>`
    : `<input type="checkbox" disabled>`;
}

dv.table(
  ["Device", "Monitored?", "OSes", "IP", "Description"],
  dv.pages()
    .where(p => 
      p["entity type"] &&
      p["entity type"].includes("device") &&
      p.file.name !== "Device template"
    )
    .map(p => [
      wrapLink(p.file.link, 150),
      renderCheckbox(p["monitored?"]),
      wrapText(p["OSes"], 200),
      wrapText(p.IP, 150),
      wrapText(p.description, 250)
    ])
);
```

> [!tip] Whoa! That's a lot of devices!
> Several of these devices (like [[vyos-sw-lan]], [[vyos-sw-dmz]], [[pfSense-extfw]], and [[pfSense-infw]]) probably won't play much of any role in your [[Modifications]] or [[Experiments]], but they're still included here *just in case* you want to play with them.


# Windows
- [[ad01]]
- [[ART Workstation]]
- [[USERENDPOINT]]

# Linux (Ubuntu)
- [[observer]]
- [[wazuh-siem]]
- [[Blue-Team Workstation]]

# FreeBSD
- [[pfSense-infw]]
- [[pfSense-extfw]]

# Linux (VyOS)
- [[vyos-sw-dmz]]
- [[vyos-sw-lan]]


> [!faq]- Want to add a new device? 
> - The template is located at [[Device template]].
> - Since you can't add additional endpoints into the Cloudshare environment, you probably won't need to use this template during this project. However, it's still provided for you in case you want to reuse this Obsidian vault for another project later.